function customerdashboard(){
    return ( 
    <div>
                <h1> Customer Dashboard Page </h1>
            </div>
    );
}   
export  default customerdashboard